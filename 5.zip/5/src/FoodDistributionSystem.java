import javax.swing.*;
import java.awt.*;

public class FoodDistributionSystem {
    private JFrame loginFrame;
    private JFrame mainMenuFrame;
    private DatabaseHandler dbHandler;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            FoodDistributionSystem system = new FoodDistributionSystem();
            system.initialize();
        });
    }

    public void initialize() {
        dbHandler = new DatabaseHandler(this);
        createLoginFrame(); 
        createMainMenuFrame();
    }

    private void createLoginFrame() {
        loginFrame = new JFrame("Login");
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginFrame.setSize(300, 200);
        loginFrame.setLayout(new BorderLayout());
        loginFrame.add(new LoginPanel(dbHandler), BorderLayout.CENTER);
        loginFrame.setVisible(true);
    }

    private void createMainMenuFrame() {
        mainMenuFrame = new MainMenuFrame(dbHandler);
        mainMenuFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainMenuFrame.setSize(300, 200);
    }

    public void showMainMenu() {
        loginFrame.setVisible(false);
        mainMenuFrame.setVisible(true);
    }
}

