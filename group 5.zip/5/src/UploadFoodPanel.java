import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UploadFoodPanel extends JPanel {
	private DatabaseHandler dbHandler;
	private MainMenuFrame mainMenuFrame;

    public UploadFoodPanel(DatabaseHandler dbHandler,MainMenuFrame mainMenuFrame) {
        this.dbHandler = dbHandler;
        this.mainMenuFrame = mainMenuFrame;
        setLayout(new GridLayout(5, 2));

        JLabel nameLabel = new JLabel("Food Name:");
        JLabel quantityLabel = new JLabel("Quantity:");
        JLabel locationLabel = new JLabel("Location:");
        JTextField nameField = new JTextField(15);
        JTextField quantityField = new JTextField(15);
        JTextField locationField = new JTextField(15);
        JButton uploadButton = new JButton("Upload");
        JButton backButton = new JButton("Back");

        uploadButton.addActionListener(e -> {
            String name = nameField.getText();
            int quantity = Integer.parseInt(quantityField.getText());
            String location = locationField.getText();
            dbHandler.uploadFood(name, quantity, location);
            JOptionPane.showMessageDialog(null, "Uplode successfully!");
        });
        
        backButton.addActionListener(e -> mainMenuFrame.switchToMainMenu());

        add(nameLabel);
        add(nameField);
        add(quantityLabel);
        add(quantityField);
        add(locationLabel);
        add(locationField);
        add(uploadButton);
        add(backButton);
    }
}