import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableModel;


public class DatabaseHandler implements DatabaseOperations{
	static String server = "jdbc:mysql://140.119.19.73:3315/";
	static String database = "112306003"; // change to your own database
	static String url = server + database + "?useSSL=false";
	static String username = "112306003"; // change to your own username
	static String password = "wz7wu"; // change to your own password
    private MainMenuFrame mainMenuFrame;
    
    private FoodDistributionSystem system;
    
    public DatabaseHandler(FoodDistributionSystem system) { // 修改构造函数
        this.system = system;
    }

    
    
    public void setMainMenuFrame(MainMenuFrame mainMenuFrame) {
        this.mainMenuFrame = mainMenuFrame;
    }

    public void registerUser(String username, String password) {
        try (Connection connection = DriverManager.getConnection(url, this.username, this.password);
             PreparedStatement statement = connection.prepareStatement("INSERT INTO users (Username, Password) VALUES (?, ?)")) {
            statement.setString(1, username);
            statement.setString(2, password);
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, "User registered successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error registering user!");
        }
    }

    public void loginUser(String username, String password) {
        try (Connection connection = DriverManager.getConnection(url, this.username, this.password);
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM users WHERE Username = ? AND Password = ?")) {
            statement.setString(1, username);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                JOptionPane.showMessageDialog(null, "Login successful!");
                system.showMainMenu(); // 通知主系统显示主菜单
            } else {
                JOptionPane.showMessageDialog(null, "Invalid username or password!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error logging in!");
        }
    }
    public void uploadFood(String foodName, int quantity, String location) {
        try (Connection connection = DriverManager.getConnection(url, this.username, this.password);
             PreparedStatement statement = connection.prepareStatement("INSERT INTO food (name, quantity, location) VALUES (?, ?, ?)")) {
            statement.setString(1, foodName);
            statement.setInt(2, quantity);
            statement.setString(3, location);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error uploading food!");
        }
    }

    @Override
    public void viewFood(JTable table) {
        String[] columnNames = {"ID", "Name", "Quantity", "Location", "Reserve"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);

        try (Connection connection = DriverManager.getConnection(url, this.username, this.password);
             Statement statement = connection.createStatement()) {

            ResultSet resultSet = statement.executeQuery("SELECT id, name, quantity, location FROM food");

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                int quantity = resultSet.getInt("quantity");
                String location = resultSet.getString("location");
                model.addRow(new Object[]{id, name, quantity, location, "Reserve"});
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        table.setModel(model);
    }



    public void reserveFood(int id) {
        try (Connection connection = DriverManager.getConnection(url, this.username, this.password)) {
            connection.setAutoCommit(false);

            try (PreparedStatement selectStatement = connection.prepareStatement("SELECT quantity FROM food WHERE id = ? FOR UPDATE")) {
                selectStatement.setInt(1, id);
                ResultSet resultSet = selectStatement.executeQuery();

                if (resultSet.next()) {
                    int quantity = resultSet.getInt("quantity");

                    if (quantity > 0) {
                        try (PreparedStatement updateStatement = connection.prepareStatement("UPDATE food SET quantity = ? WHERE id = ?")) {
                            updateStatement.setInt(1, quantity - 1);
                            updateStatement.setInt(2, id);
                            updateStatement.executeUpdate();
                        }

                        if (quantity - 1 == 0) {
                            try (PreparedStatement deleteStatement = connection.prepareStatement("DELETE FROM food WHERE id = ?")) {
                                deleteStatement.setInt(1, id);
                                deleteStatement.executeUpdate();
                            }
                        }

                        connection.commit();
                        JOptionPane.showMessageDialog(null, "Reservation successful!");
                    } else {
                        JOptionPane.showMessageDialog(null, "Food is no longer available!");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Food not found!");
                }
            } catch (SQLException e) {
                connection.rollback();
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error reserving food!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Database connection error!");
        }
    }
}